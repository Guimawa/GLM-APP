GLM Services – PWA

✅ Pour tester localement :
- Ouvrir index.html dans un navigateur (Chrome recommandé)
- Autoriser l'installation en tant qu'application (Ajouter à l'écran d'accueil)

✅ Pour héberger :
- Uploadez le dossier complet sur Netlify, Vercel, Firebase Hosting ou autre service web

✅ Structure :
- index.html : l'application
- manifest.json : pour rendre l'app installable
- sw.js : service worker de base
- icon-*.png : icônes d'application

Parfait pour une app mobile sans passer par les stores.
